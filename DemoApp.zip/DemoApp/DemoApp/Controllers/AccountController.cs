﻿using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
