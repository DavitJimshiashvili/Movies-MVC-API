﻿using DemoApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoApp.Database.Configurations
{
    public class WalletConfiguration:IEntityTypeConfiguration<Wallet>
    {
        public void Configure(EntityTypeBuilder<Wallet> builder)
        {

            builder.HasKey(wallet => wallet.PlayerId);
            builder.Property(wallet => wallet.CurrencyCode).IsRequired().IsUnicode(false);
            builder.Property(wallet => wallet.Balance).IsRequired().HasPrecision(18, 2);

            builder.HasMany(wallet => wallet.Transactions)
                .WithOne(t=>t.Wallet)
                .HasForeignKey(t=>t.PlayerId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
