﻿using DemoApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoApp.Database.Configurations
{
    public class PlayerConfiguration : IEntityTypeConfiguration<Player>
    {
        public void Configure(EntityTypeBuilder<Player> builder)
        {
            builder.HasKey(player => player.Id);
            builder.Property(player => player.Id).ValueGeneratedOnAdd();
            builder.Property(player => player.UserName)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            builder.HasOne(player => player.Wallet)
                .WithOne(player => player.Player)
                .HasForeignKey<Wallet>(wallet=> wallet.PlayerId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
