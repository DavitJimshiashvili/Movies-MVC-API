﻿using DemoApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoApp.Database.Configurations
{
    public class AccountConfiguration:IEntityTypeConfiguration<Account>
    {
        public void Configure(EntityTypeBuilder<Account> builder)
        {
            builder.HasKey(acc => acc.Id);
            builder.Property(acc => acc.Id).ValueGeneratedOnAdd();

            builder.Property(acc => acc.CurrencyCode).IsRequired().IsUnicode(false);
            builder.Property(acc => acc.Balance).IsRequired().HasPrecision(18, 2);


            builder.HasMany(acc=>acc.Transactions)
                .WithOne(tr => tr.Account)
                .HasForeignKey(tr=>tr.AccountId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(a => a.User)
                .WithOne(u=>u.Account)
                .HasForeignKey<User>(a=>a.AccountId)
                .OnDelete(DeleteBehavior.NoAction);

        }
    }
}
