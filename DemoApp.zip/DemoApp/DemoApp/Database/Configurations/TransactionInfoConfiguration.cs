﻿using DemoApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoApp.Database.Configurations
{
    public class TransactionInfoConfiguration : IEntityTypeConfiguration<TransactionInfo>
    {
        public void Configure(EntityTypeBuilder<TransactionInfo> builder)
        {
            builder.HasKey(ti => ti.TransactionId);

            builder.Property(ti => ti.RoundId).IsRequired();
            builder.Property(ti => ti.GameName).IsRequired();
            builder.Property(ti => ti.GameNumber).IsRequired();
        }
    }
}
