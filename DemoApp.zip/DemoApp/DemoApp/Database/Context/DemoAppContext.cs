﻿using DemoApp.Models;
using System;
using Microsoft.EntityFrameworkCore;

namespace DemoApp.Database.Context
{
    public class DemoAppContext : DbContext
    {

        public DemoAppContext(DbContextOptions<DemoAppContext> options) : base(options)
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(DemoAppContext).Assembly);
            base.OnModelCreating(modelBuilder);
        }
    }
}
