﻿using DemoApp.Models;
using System;
using Microsoft.EntityFrameworkCore;

namespace DemoApp.Database.Context
{
    public class DemoAppContext : DbContext
    {

        public DemoAppContext(DbContextOptions<DemoAppContext> options) : base(options)
        {

        }

        public DbSet<Player> Players { get; set; }
        public DbSet<Wallet> Wallets { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<TransactionInfo> TransactionInfos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(DemoAppContext).Assembly);
            base.OnModelCreating(modelBuilder);
        }
    }
}
