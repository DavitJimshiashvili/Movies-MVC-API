﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface IAccountRepository:IBaseRepository<Account>
    {
        Task<Account> GetBalance(int accountId);

    }
}
