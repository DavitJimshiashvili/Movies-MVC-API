﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface IUserRepository:IBaseRepository<User>
    {
        Task <decimal> Deposit(int accountId, decimal amount);
        Task <decimal> Withdraw(int accountId, decimal amount);
    }
}
