﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface IPlayerRepository
    {
        Task<Wallet> GetBalance(string username);

    }
}
