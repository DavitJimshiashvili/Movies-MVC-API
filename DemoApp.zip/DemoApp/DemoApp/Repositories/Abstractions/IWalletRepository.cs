﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface IWalletRepository
    {
        public Task<Wallet> GetAccount(string userName);
        public Task Deposit(int accountId, decimal amount);
        public Task Withdraw(int accountId, decimal amount);

    }
}
