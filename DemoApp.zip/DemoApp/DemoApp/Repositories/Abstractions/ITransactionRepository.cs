﻿using DemoApp.Models;
using DemoApp.Repositories.Base;

namespace DemoApp.Repositories.Abstractions
{
    public interface ITransactionRepository:IBaseRepository<Transaction>
    {


    }
}
