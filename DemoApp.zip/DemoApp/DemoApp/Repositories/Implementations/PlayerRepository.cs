﻿using DemoApp.Models;
using DemoApp.Repositories.Abstractions;
using DemoApp.Repositories.Base;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Implementations
{
    public class PlayerRepository : IPlayerRepository
    {
        private readonly IBaseRepository<Player> _repo;
        public PlayerRepository(IBaseRepository<Player> repo)
        {
            _repo = repo;
        }
     

        public async Task<Wallet> GetBalance(string username)
        {
            return await _repo.Table.Where(us=>us.UserName==username)
                .Select(us=>us.Wallet)
                .SingleOrDefaultAsync();
        }
    }
}
