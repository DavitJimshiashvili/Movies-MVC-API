﻿using DemoApp.Models;
using DemoApp.Repositories.Abstractions;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Implementations
{
    public class TransactionRepository : ITransactionRepository
    {

        private readonly IBaseRepository<Transaction> _repo;
        public TransactionRepository(IBaseRepository<Transaction> repo)
        {
            _repo = repo;
        }
        public async Task<bool> Deposit(Transaction transaction)
        {
            await _repo.AddAsync(transaction);
            return true;
        }

        public Task<bool> Withdraw(Transaction transaction)
        {
            throw new System.NotImplementedException();
        }
    }
}
