﻿using DemoApp.Database.Context;
using DemoApp.Models;
using DemoApp.Repositories.Abstractions;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Implementations
{
    public class AccountRepository : BaseRepository<Account>, IAccountRepository
    {

        public AccountRepository(DemoAppContext ctx) : base(ctx)
        {
        }
        public Task<Account> GetBalance(int accountId)
        {
            throw new System.NotImplementedException();
        }
    }
}
