﻿using DemoApp.Database.Context;
using DemoApp.Models;
using DemoApp.Repositories.Abstractions;
using DemoApp.Repositories.Base;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Implementations
{
    public class WalletRepository : IWalletRepository
    {
        private readonly IBaseRepository<Wallet> _repo;

        public WalletRepository(IBaseRepository<Wallet> repo)
        {
            _repo = repo;
        }

        public async Task Deposit(int accountId, decimal amount)
        {
            var account = await _repo.GetAsync(accountId);
            account.Balance += amount;
            await _repo.UpdateAsync(account);
        }

        public Task<Wallet> GetAccount(string userName)
        {
            throw new System.NotImplementedException();
        }

        public async Task Withdraw(int accountId, decimal amount)
        {
            var account=await _repo.GetAsync(accountId);
            account.Balance-=amount;
            await _repo.UpdateAsync(account);
        }
    }
}
