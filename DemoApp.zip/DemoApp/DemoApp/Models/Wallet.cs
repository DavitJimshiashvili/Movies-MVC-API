﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models
{
    public class Wallet
    { 
        [Required]
        public decimal Balance { get; set; }
        [Required]
        public string CurrencyCode { get; set; }
        public List<Transaction> Transactions { get; set; }

        public Player Player { get; set; }
        public string PlayerId { get; set; }
    }
}
