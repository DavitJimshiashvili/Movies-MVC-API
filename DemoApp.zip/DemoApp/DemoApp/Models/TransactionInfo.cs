﻿namespace DemoApp.Models
{
    public class TransactionInfo
    {
        public string Source { get; set; }
        public string GameName { get; set; }
        public string RoundId { get; set; }
        public string GameNumber { get; set; }
        public string CashierTransactionId { get; set; }

        public Transaction  Transaction{ get; set; }
        public string TransactionId { get; set; }
    }
}
