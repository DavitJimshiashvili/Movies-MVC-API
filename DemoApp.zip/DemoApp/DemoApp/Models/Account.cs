﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models
{
    public class Account
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public decimal? Balance { get; set; }
        [Required]
        public string CurrencyCode { get; set; }

        public List<Transaction> Transactions { get; set; }



        public string UserId { get; set; }
        public User User{ get; set; }//navigation prop


    }
}
