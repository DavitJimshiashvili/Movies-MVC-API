﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models
{
    public class Transaction
    {
        [Required]
        public string TransactionId { get; set; }
        
        [Required]
        public virtual string TransactionType { get; set; }

        [Required]
        public string CurrencyCode { get; set; }
        [Required]
        public decimal Amount { get; set; }

        [Required]
        public TransactionInfo TransactionInfo{ get; set; }

        public Wallet Wallet { get; set; }
        public string PlayerId { get; set; }

    }
}
