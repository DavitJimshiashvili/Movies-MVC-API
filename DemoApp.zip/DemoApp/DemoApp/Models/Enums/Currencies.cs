﻿namespace DemoApp.Models.Enums
{
    public static class Currencies
    {
        public const string USD = "USD";
        public const string EUR = "EUR";
        public const string GEL = "GEL";
    }
}
