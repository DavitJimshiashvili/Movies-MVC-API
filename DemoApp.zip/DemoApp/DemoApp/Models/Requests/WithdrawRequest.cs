﻿using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models.Requests
{
    public class WithdrawRequest
    {
        [Required]
        public string TransactionId { get; set; }

        [Required]
        public string TransactionType { get; set; }

        [Required]
        public string CurrencyCode { get; set; }

        [Required]
        public decimal Amount { get; set; }
    }
}
