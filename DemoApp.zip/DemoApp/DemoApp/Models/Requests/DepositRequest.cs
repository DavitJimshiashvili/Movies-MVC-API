﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models.InputModels
{
    public class DepositRequest
    {
        [Required]
        public  string TransactionId { get; set; }

        [Required]
        public string TransactionType { get; set; }

        [Required]
        public string CurrencyCode { get; set; }

        [Required]
        public decimal Amount { get; set; }
    }
}
