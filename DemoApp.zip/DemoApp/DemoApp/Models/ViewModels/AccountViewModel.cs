﻿namespace DemoApp.Models.ViewModels
{
    public class AccountViewModel
    {
        public decimal? Balance { get; set; }

        public string CurrencyCode { get; set; }
    }
}
