﻿namespace DemoApp.Models.ViewModels
{
    public class WalletViewMode
    {

        public decimal Balance { get; set; }
        public string CurrencyCode { get; set; }

    }
}
