﻿using DemoApp.Database.Context;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using DemoApp.Models;
using System.Collections.Generic;
using System.Linq;
using DemoApp.Models.Enums;

namespace DemoApp.Database.Seed
{
    public static  class DataSeed
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {

            using var scope = serviceProvider.CreateScope();
            var database = scope.ServiceProvider.GetRequiredService<DemoAppContext>();

            Migrate(database);
            SeedEverything(database);
        }

        private static void SeedEverything(DemoAppContext context)
        {
            if (!context.Users.Any())
            {
                context.Users.AddRange(
                    new User
                    {
                        Username = "Davit111",
                    },
                    new User
                    {
                        Username = "Player1",

                        Account=new Account
                        {
                            Balance=200.5m,
                            CurrencyCode=Currencies.USD,

                            Transactions=new List<Transaction>
                            {
                                new Transaction
                                {
                                    Amount=30,
                                    CurrencyCode=Currencies.USD,
                                    TransactionType=TransactionTypes.PlaceBet
                                }
                                        
                            }
                                   
                        }
                        
                    }
                    );;
                context.SaveChanges();
            }
       
        }

        private static void Migrate(DemoAppContext context)
        {
            context.Database.Migrate();
        }

    }
}
