﻿using DemoApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace DemoApp.Database.Configurations
{
    public class TransactionConfiguration:IEntityTypeConfiguration<Transaction>
    {
        public void Configure(EntityTypeBuilder<Transaction> builder)
        {
            builder.HasKey(t => t.Id);
            builder.Property(t=>t.Id).ValueGeneratedOnAdd();
            builder.Property(t => t.Amount).IsRequired().HasPrecision(8,2);
            builder.Property(t => t.TransactionType).IsRequired();


        }
    }
}
