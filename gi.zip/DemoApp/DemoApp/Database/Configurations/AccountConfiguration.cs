﻿using DemoApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DemoApp.Database.Configurations
{
    public class AccountConfiguration:IEntityTypeConfiguration<Account>
    {
        public void Configure(EntityTypeBuilder<Account> builder)
        {

            builder.HasKey(acc => acc.Id);
            builder.Property(acc => acc.Id).ValueGeneratedOnAdd();

            builder.Property(acc => acc.CurrencyCode).IsRequired().IsUnicode(false);
            builder.Property(acc => acc.Balance).IsRequired().HasPrecision(18, 2);

            builder.HasMany(a=>a.Transactions)
                .WithOne(a=>a.Account)
                .HasForeignKey(a=>a.AccountId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
