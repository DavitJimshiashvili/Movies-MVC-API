﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface IAccountRepository
    {
        public Task<Account> GetAccount(int accountId);
        public Task<bool> Exists(int accountId);
        public Task Deposit(int accountId, decimal? amount);
        public Task Withdraw(int accountId, decimal? amount);

    }
}
