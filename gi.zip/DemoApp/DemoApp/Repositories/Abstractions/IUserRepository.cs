﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface IUserRepository
    {
        Task<Account> GetBalance(string username);

    }
}
