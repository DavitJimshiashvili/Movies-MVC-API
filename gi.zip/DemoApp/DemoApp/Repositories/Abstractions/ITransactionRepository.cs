﻿using DemoApp.Models;
using DemoApp.Repositories.Base;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Abstractions
{
    public interface ITransactionRepository
    {
        Task<bool> Deposit(Transaction transaction);
        Task<bool> Withdraw(Transaction transaction);

    }
}
