﻿using DemoApp.Database.Context;
using DemoApp.Models;
using DemoApp.Repositories.Abstractions;
using DemoApp.Repositories.Base;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Implementations
{
    public class AccountRepository : IAccountRepository
    {
        private readonly IBaseRepository<Account> _repo;

        public AccountRepository(IBaseRepository<Account> repo)
        {
            _repo = repo;
        }

        public async Task Deposit(int accountId, decimal? amount)
        {
            var account = await _repo.GetAsync(accountId);
            account.Balance += amount;
            await _repo.UpdateAsync(account);
        }

        public async Task<bool> Exists(int accountId)
        {
            return await _repo.AnyAsync(acc=>acc.Id == accountId);
        }

        public async  Task<Account> GetAccount(int accountId)
        {

           return await _repo.Table
                .Where(acc=>acc.Id==accountId)
                .SingleOrDefaultAsync();
        }

        public async Task Withdraw(int accountId, decimal? amount)
        {
            var account=await _repo.GetAsync(accountId);
            account.Balance-=amount;
            await _repo.UpdateAsync(account);
        }
    }
}
