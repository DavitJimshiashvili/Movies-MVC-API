﻿using DemoApp.Models;
using DemoApp.Repositories.Abstractions;
using DemoApp.Repositories.Base;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Repositories.Implementations
{
    public class UserRepository : IUserRepository
    {
        private readonly IBaseRepository<User> _repo;
        public UserRepository(IBaseRepository<User> repo)
        {
            _repo = repo;
        }
     

        public async Task<Account> GetBalance(string username)
        {
            return await _repo.Table.Where(us=>us.Username==username)
                .Select(us=>us.Account)
                .SingleOrDefaultAsync();
        }
    }
}
