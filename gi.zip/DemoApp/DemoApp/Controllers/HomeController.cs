﻿using DemoApp.Models;
using DemoApp.Models.Enums;
using DemoApp.Models.InputModels;
using DemoApp.Models.ViewModels;
using DemoApp.Repositories.Abstractions;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IUserRepository _userRepo;
        private readonly ITransactionRepository _transactionRepo;
        private readonly IAccountRepository _accountRepo;
        int accountId = 1;
        public HomeController(ILogger<HomeController> logger, IUserRepository userRepo, ITransactionRepository transactionRepo,IAccountRepository accountRepo)
        {
            _logger = logger;
            _userRepo = userRepo;
            _transactionRepo = transactionRepo;
            _accountRepo = accountRepo;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        [Route("getbalance")]
        public async Task<IActionResult> GetBalance (string username)
        {
            if (username == null )
                return NotFound();

            var account = await _userRepo.GetBalance(username);
            var mappedToVIew = account.Adapt<AccountViewModel>();

            return View(mappedToVIew);
        }


        [HttpGet]
        public async Task<IActionResult> Deposit()
        {
            return View(await _accountRepo.GetAccount(accountId));
        }
        [HttpPost]
        public async Task<IActionResult> Deposit(TransactionInputModel transaction)
        {
            await _accountRepo.Deposit(accountId, transaction.Amount);
            await _transactionRepo.Deposit(new Transaction
            {
                Amount = transaction.Amount,
                TransactionType=TransactionTypes.PlaceBet,
                CurrencyCode=transaction.CurrencyCode

            });
            return View(await _accountRepo.GetAccount(accountId));
        }


        public  IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
