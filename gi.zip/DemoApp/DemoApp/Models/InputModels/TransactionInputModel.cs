﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models.InputModels
{
    public class TransactionInputModel
    {
        [Required]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required]
        public string TransactionType { get; set; }

        [Required]
        public string CurrencyCode { get; set; }

        [Required]
        public decimal Amount { get; set; }
    }
}
