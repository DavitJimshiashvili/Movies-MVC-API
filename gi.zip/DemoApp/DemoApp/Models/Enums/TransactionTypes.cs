﻿namespace DemoApp.Models.Enums
{
    public static class TransactionTypes
    {
        public const string InitialBet = "InitialBet";
        public const string PlaceBet = "PlaceBet";
        public const string WinAmount = "WinAmount";
    }
}
