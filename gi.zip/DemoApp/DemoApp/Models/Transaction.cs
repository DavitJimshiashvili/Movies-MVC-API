﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DemoApp.Models
{
    public class Transaction
    {
        [Required]
        public string Id { get; set; }
        
        [Required]
        public string TransactionType { get; set; }

        [Required]
        public string CurrencyCode { get; set; }
        [Required]
        public decimal Amount { get; set; }

        public Account Account { get; set; }
        public int AccountId { get; set; }


    }
}
