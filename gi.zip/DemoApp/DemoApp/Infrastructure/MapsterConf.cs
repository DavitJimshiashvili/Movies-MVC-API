﻿using DemoApp.Models;
using DemoApp.Models.InputModels;
using DemoApp.Models.ViewModels;
using Mapster;
using Microsoft.Extensions.DependencyInjection;

namespace DemoApp.Infrastructure
{
    public static class MapsterConf
    {
        public static void RegisterMaps(this IServiceCollection service)
        {
            TypeAdapterConfig<Account, AccountViewModel>.NewConfig().TwoWays();
            TypeAdapterConfig<AccountViewModel, Account>.NewConfig().TwoWays();
            TypeAdapterConfig<TransactionInputModel, Transaction>.NewConfig().TwoWays();
            TypeAdapterConfig<Transaction, TransactionInputModel>.NewConfig().TwoWays();
        }
    }
}
